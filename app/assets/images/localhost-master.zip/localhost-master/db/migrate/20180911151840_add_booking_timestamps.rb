class AddBookingTimestamps < ActiveRecord::Migration[5.2]
  def change
    add_timestamps(:bookings)
  end
end
