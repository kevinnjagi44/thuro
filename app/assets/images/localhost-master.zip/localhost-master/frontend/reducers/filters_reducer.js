import { combineReducers } from 'redux';
import bounds from './bounds_reducer';

export default combineReducers({
  bounds
});
